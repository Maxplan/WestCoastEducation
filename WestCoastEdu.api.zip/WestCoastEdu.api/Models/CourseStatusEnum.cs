namespace WestCoastEdu.api.Models
{
    public enum CourseStatusEnum
    {
        Upcoming = 0,
        Ongoing = 1,
        Completed = 2
    }
}